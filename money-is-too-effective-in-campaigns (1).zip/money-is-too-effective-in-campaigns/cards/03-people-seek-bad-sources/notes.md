# People seek bad sources

*Pattern*

People are more persuaded by partisan messaging than not

## Built from

  • Evidence: Factcheckers powerless — Objective fact checkers only have a sliver of influence compared to other vested interest
    - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
    - Signal "Media Misinformation": Broad concerns regarding how misleading media and digital influencing are negatively impacting civic engagement.
  • Evidence: People are easily persuaded by campaign ads — Campaigns can influence voters easily through ads
    - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
    - Signal "voter literacy": Why do ads have such a strong effect? Why does money in elections work?
    - Signal "Media Misinformation": Broad concerns regarding how misleading media and digital influencing are negatively impacting civic engagement.
    - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
