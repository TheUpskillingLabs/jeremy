# $ has too much power in campaigns

*Evidence · Evidence*

Groups can easily influence campaigns with more $

## Built from

  - Signal "Campaign Finance": Reform efforts consistently hit roadblocks like the Citizens United decision.
  - Signal "$ in politics": Entrenched actors (AIPAC), ideological. New actors (crypto, AI companies)
  - Signal "Campaign Finance & District Competitiveness": Observations that financial influence and gerrymandering have reduced the competitiveness of congressional districts.
