# Factcheckers powerless

*Evidence · Evidence*

Objective fact checkers only have a sliver of influence compared to other vested interest

## Built from

  - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
  - Signal "Media Misinformation": Broad concerns regarding how misleading media and digital influencing are negatively impacting civic engagement.
